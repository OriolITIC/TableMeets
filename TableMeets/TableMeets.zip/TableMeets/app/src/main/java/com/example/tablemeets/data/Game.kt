package com.example.tablemeets.data

class Game {
}