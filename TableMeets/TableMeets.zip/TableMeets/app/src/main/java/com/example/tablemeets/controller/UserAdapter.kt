package com.example.tablemeets.controller

class UserAdapter {
}