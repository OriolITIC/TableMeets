package com.example.tablemeets

class DescriptionAttendingEvent {
}